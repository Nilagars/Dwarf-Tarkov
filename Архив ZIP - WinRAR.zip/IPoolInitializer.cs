namespace InsaneScatterbrain.ScriptGraph
{
    public interface IPoolInitializer
    {
        void Initialize(PoolManager poolManager);
    }
}