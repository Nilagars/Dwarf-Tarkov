namespace InsaneScatterbrain.MapGraph
{
    public enum HexagonalGridOffsetType
    {
        OddRows,
        EvenRows,
        None
    }
}