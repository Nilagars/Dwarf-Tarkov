using System.Collections.Generic;

namespace InsaneScatterbrain.MapGraph
{
    public class ListPool<TValue> : CollectionPool<List<TValue>, TValue>
    {
    }
}