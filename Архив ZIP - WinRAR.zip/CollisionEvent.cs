﻿
namespace FunkyCode.EventHandling
{
    public delegate void CollisionEvent2D(LightCollision2D collision);
}