namespace InsaneScatterbrain.MapGraph
{
    public enum DomainWarpFractalType 
    {
        None,
        DomainWarpProgressive, 
        DomainWarpIndependent 
    };
}