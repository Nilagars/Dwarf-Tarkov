namespace InsaneScatterbrain.MapGraph
{
    public enum FractalType 
    {
        None,
        FBm, 
        Ridged, 
        PingPong
    };
}