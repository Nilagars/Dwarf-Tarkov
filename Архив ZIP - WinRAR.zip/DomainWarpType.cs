namespace InsaneScatterbrain.MapGraph
{
    public enum DomainWarpType 
    { 
        None,
        OpenSimplex2, 
        OpenSimplex2Reduced, 
        BasicGrid 
    };
}